<?php
/**
 * @package Testimonial
 * @version 1.0
 */
/*
Plugin Name: Testmonial
Plugin URI:
Description: This is simple testimonial Plugin
Author: imran rahman
Version: 1.0
Author URI: http://imran.com/
*/

include_once 'testimonial_widget_class.php';

class Testimonial
{
    const PT = 'Testimonials';
    public static $class = __CLASS__;
    const ID = 'testimonials-testimonials';
    public static $fields = array(
        array(
            'name' => 'Job Title',
            'id' => 'testimonials-title',
            'type' => 'text',
            'desc' => '',
        ),
        array(
            'name' => 'Location',
            'id' => 'testimonials-location',
            'type' => 'text',
            'desc' => '',
        ),
        array(
            'name' => 'Email',
            'id' => 'testimonials-email',
            'type' => 'text',
            'desc' => '',
        ),
        array(
            'name' => 'Company',
            'id' => 'testimonials-company',
            'type' => 'text',
            'desc' => '',
        ),
        array(
            'name' => 'URL',
            'id' => 'testimonials-url',
            'type' => 'text',
            'desc' => '',
        ),
    );


    public function __construct()
    {
        add_action( 'wp_enqueue_scripts',array(__CLASS__, 'my_scripts'));
        add_action('init', array(__CLASS__, 'init_post_type'));
        add_action('admin_menu', array(__CLASS__, 'register_testimonial_submenu_setting'));
        add_filter('manage_edit-testimonials_columns', array(__CLASS__, 'edit_testimonial_columns'));
        add_action('add_meta_boxes_testimonials', array(__CLASS__, 'testimonial_metabox'));
        add_action('save_post', array(__CLASS__, 'testimonial_metabox_save'));
        add_action('manage_posts_custom_column', array(__CLASS__, 'custom_testimonials_column'), 10, 2);
    }


    public function my_scripts() {
        wp_enqueue_script(
            'easy-testimonial',
            plugins_url( '/js/jquery.cycle.all.js' , __FILE__ ),

            array( 'jquery' )
        );

         wp_enqueue_script(
            'script',
            plugins_url( '/js/script.js' , __FILE__ ), array(jquery));
    }



    public static function edit_testimonial_columns($columns)
    {

        $columns = array(
            'cb' => '<input type="checkbox" />',
            'id' => esc_html__('ID', 'testimonials'),
            'thumbnail' => esc_html__('Image', 'testimonials'),
            'title' => esc_html__('Title', 'testimonials'),
            'testimonials-email' => esc_html__('Email', 'testimonials'),
            'testimonials-company' => esc_html__('Company', 'testimonials'),
            'author' => esc_html__('Published by', 'testimonials'),

        );

        return $columns;
    }


    function custom_testimonials_column($column, $post_id)
    {

        global $post;

        switch ($column) {
            case 'testimonials-email':
                echo get_post_meta($post_id, 'testimonials-email', true);
                break;

            case 'testimonials-company':
                echo get_post_meta($post_id, 'testimonials-company', true);
                break;

            case 'thumbnail':
                 if ( has_post_thumbnail() ) { // check if the post has a Post Thumbnail assigned to it.
                     the_post_thumbnail('thumbnail');
                  }else{
                     echo get_avatar(get_the_author_meta('ID'), '', '', 'default photo');
                 }
                break;
        }
    }

    public static function init_post_type()
    {
        $labels = array(
            'add_new' => esc_html__('Add New', 'testimonials'),
            'add_new_item' => esc_html__('Add New Testimonial', 'testimonials'),
            'edit_item' => esc_html__('Edit Testimonial', 'testimonials'),
            'name' => esc_html__('Testimonials', 'testimonials'),
            'new_item' => esc_html__('Add New Testimonial', 'testimonials'),
            'not_found' => esc_html__('No testimonials found', 'testimonials'),
            'not_found_in_trash' => esc_html__('No testimonials found in Trash', 'testimonials'),
            'parent_item_colon' => null,
            'search_items' => esc_html__('Search Testimonials', 'testimonials'),
            'singular_name' => esc_html__('Testimonial', 'testimonials'),
            'view_item' => esc_html__('View Testimonial', 'testimonials'),
        );


        $args = array(
            'label' => esc_html__('Testimonials', 'testimonials'),
            'capability_type' => 'post',
            'hierarchical' => false,
            'labels' => $labels,
            'public' => true,
            'publicly_queryable' => true,
            'query_var' => true,
            'rewrite' => array(),
            'supports' => array(
                'title',
                'editor',
                'thumbnail'
            ),
            'taxonomies' => array('category'),
        );

        register_post_type(self::PT, $args);


    }

    function register_testimonial_submenu_setting()
    {

        add_submenu_page(
            'edit.php?post_type=testimonials',
            'Settings',
            'Settings',
            'manage_options',
            'testimonial_sub_menu_page',
            array(__CLASS__, 'testimonial_submenu_page_callback')
        );

    }

    function testimonial_submenu_page_callback()
    {

        echo '<div class="wrap"><div id="icon-tools" class="icon32"></div>';
        echo '<h2>My Custom Submenu Page</h2>';
        echo '</div>';

    }

    public static function testimonial_metabox($testimonial)
    {
        add_meta_box(
            'testimonials_meta_box',
            __('Testimonial Field'),
            array(__CLASS__, 'render_my_testimonial_box'),
            'testimonials',
            'normal',
            'default'
        );

    }

    public function render_my_testimonial_box($testimonial)
    {

        foreach (self::$fields as $field) {
            $value = $testimonial->ID ? get_post_meta($testimonial->ID, $field['id'], true) : '';
            switch ($field['type']) {
                case  'text':
                    ?>
                    <tr>
                        <th scope="row" style="width: 140px">
                            <label for="<?php echo $field['id']; ?>"><?php echo $field['name']; ?></label>
                        </th>
                        <td>
                            <input  <?php echo $field['attributes'] ?>
                                id="<?php echo $field['id']; ?>"
                                value="<?php echo $value; ?>"
                                type="<?php echo $field['type']; ?>"
                                name="<?php echo $field['id']; ?>"
                                class="text large-text "/>
                            <span class="description"><?php echo $field['desc']; ?></span>
                        </td>
                    </tr>
                    <?php break;
            }
        }
    }

    public function  testimonial_metabox_save($post_id)
    {
        if ($_POST) {
            foreach (self::$fields as $field) {
                update_post_meta($post_id, $field['id'], $_POST[$field['id']]);
            }

        }
    }

    public static function activation()
    {
        self::init();
        flush_rewrite_rules();
    }


    public static function deactivation()
    {

        flush_rewrite_rules();
    }

}

register_activation_hook(__FILE__, array('Testimonial', 'activation'));
register_deactivation_hook(__FILE__, array('Testimonial', 'deactivation'));
add_action('plugins_loaded', 'testimonial_init', 99);

function testimonial_init()
{
    //it will not try to second time make intance
    global $Testimonial;
    if (is_null($Testimonial)) {
        $Testimonial = new Testimonial();
    }
}

// register Foo_Widget widget
function register_foo_widget() {
    register_widget( 'Foo_Widget' );
}

add_action( 'widgets_init', 'register_foo_widget' );



