<style type="text/css">



    .thumb-testimonial {
        float: left;
        text-align: left;
        width: 35%;

    }

    .testimonials-list .the-post {
        float: left;
        width: 60%;


     }

    .testimonials-list .the-post p {
        margin: 0;
        color: #585555;
        font-family: 'Droid Sans', sans-serif !important;
        font-size: 0.85em;
    }

    .testimonials-list .thumb-testimonial img {
        width: 50px !important;
        height: 50px !important;

    }



</style>


<?php


/**
 * Adds Foo_Widget widget.
 */
class Foo_Widget extends WP_Widget
{

    /**
     * Register widget with WordPress.
     */
    function __construct()
    {
        parent::__construct(
            'foo_widget', // Base ID
            __('Widget Title', 'text_domain'), // Name
            array('description' => __('A Foo Widget', 'text_domain'),) // Args
        );
    }

    /**
     * Front-end display of widget.
     *
     * @see WP_Widget::widget()
     *
     * @param array $args Widget arguments.
     * @param array $instance Saved values from database.
     */
    public function widget($args, $instance)
    {
        $args = array('post_type' => 'testimonials', 'posts_per_page' => 10);
        $loop = new WP_Query($args);
        $title = apply_filters( 'widget_title', $instance['title'] );
        echo '<aside>';
        echo "<h3 class='widget-title'> $title</h3>";

        echo '<div class="slideshow">';?>


        <?php



        while ($loop->have_posts()) : $loop->the_post();?>

            <div class="testimonials-list group">

                <div class="thumb-testimonial group">
            <!--      <div  class="sphere">
                   <?php /*if ( has_post_thumbnail() ) { // check if the post has a Post Thumbnail assigned to it.
                     the_post_thumbnail('thumbnail');
                  }else{
                     echo get_avatar(get_the_author_meta('ID'), '', '', 'default photo');
                  } */?>
                 </div>-->

                </div>
                <div class="the-post group">
                    <?php echo the_content(); ?>
                    <?php the_author_meta( 'first_name' ); ?>
                     <?php $meta = get_post_meta( get_the_ID());?>

                    <?php echo  get_post_meta('ID', 'testimonials-company', true); ?>
                    <p class="name-testimonial group">
                        <span class="title special-font">Joy Mèrgot</span>

                    </p>
                </div>

            </div>

        <?php
        endwhile;
        echo '</div></aside>';
    }

    /**
     * Back-end widget form.
     *
     * @see WP_Widget::form()
     *
     * @param array $instance Previously saved values from database.
     */
    public function form($instance)
    {
        if (isset($instance['title'])) {
            $title = $instance['title'];
            $test = $instance['test'];
        } else {
            $title = __('New title', 'text_domain');
            $test = 'testig';
        }
        ?>
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:'); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>"
                   name="<?php echo $this->get_field_name('title'); ?>" type="text"
                   value="<?php echo esc_attr($title); ?>"/>
            <input class="widefat" id="<?php echo $this->get_field_id('test'); ?>"
                   name="<?php echo $this->get_field_name('test'); ?>" type="text"
                   value="<?php echo esc_attr($test); ?>"/>
        </p>
    <?php
    }

    /**
     * Sanitize widget form values as they are saved.
     *
     * @see WP_Widget::update()
     *
     * @param array $new_instance Values just sent to be saved.
     * @param array $old_instance Previously saved values from database.
     *
     * @return array Updated safe values to be saved.
     */
    public function update($new_instance, $old_instance)
    {
        $instance = array();
        $instance['title'] = (!empty($new_instance['title'])) ? strip_tags($new_instance['title']) : '';
        $instance['test'] = (!empty($new_instance['test'])) ? strip_tags($new_instance['test']) : '';


        return $instance;
    }

} // class Foo_Widget
?>

